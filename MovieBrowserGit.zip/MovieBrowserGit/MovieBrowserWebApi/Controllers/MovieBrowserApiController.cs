﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OMBEntitiesLib;//Imports All the Entities used in this Application from Entities Library Project
using OMBBusinessLayerLib;//Imports All the Functions used in this Application from BusinessLayer Library Project
using OMBDataAccessLayerLib;//Imports All the Functions used in this Application from DataAccessLayer Library Project
using OMBExceptionLib;//Imports All the Exceptions used in this Application from database
namespace MovieBrowserWebAPI.Controllers
{
    public class MovieBrowserApiController : ApiController
    {
        //Dependency Injection To the Business layer Interface
        private readonly IOMBBusinessLayer bbl;

        //constructor to invoke the variable coming from BusinessLayer Interface
        public MovieBrowserApiController(IOMBBusinessLayer bbl)
        {
            this.bbl = bbl;
        }
        /// <summary>
        /// To Get All the User Details from the database
        ///Routing Defines the path to get this method
        ///when there is an exception it throws exception to CustomExceptionFilter Class 
        /// </summary>
        /// <returns>Returns All the users from database as a HttpResponse message whether it is success or not</returns>
        [Route("api/MovieBrowserApi/GetUserDetails")]
        [CustomExceptionFilter]
        public HttpResponseMessage GetUserDetails()
        {
            //If there is no error it just create response as success code
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                //retrives all the user details and store it in a variable
                var user = bbl.GetUserDetails();
                //list of user details send to the msg variable as a httpresponse code
                msg = Request.CreateResponse<UserDetail>(HttpStatusCode.OK, user);
            }
            catch(Exception ex)
            {
                //throw exception if occurred
                throw ex;
            }
            return msg;
        }
        /// <summary>
        /// To Get All the Movie Names from the database With the given movieName by User
        ///Routing Defines the path to get this method
        ///when there is an exception it throws exception to CustomExceptionFilter Class 
        /// </summary>
        /// <param name="movieName">It is Used to pass the moviename to retrive all the movies with this parameter</param>
        /// <returns>Returns All the users from database as a HttpResponse message whether it is success or not</returns>
        [Route("api/MovieBrowserApi/GetMoviesByName/{MovieName}")]
        [CustomExceptionFilter]
        public HttpResponseMessage GetMoviesByName(string movieName)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                var moviesLst = bbl.GetMoviesByName(movieName);
                msg = Request.CreateResponse<List<Movie>>(HttpStatusCode.OK, moviesLst);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return msg;
        }
        /// <summary>
        /// To Get All the Movie Details with the help of movieid given by the user
        /// Routing Defines the path to get this method
        /// when there is an exception it throws exception to CustomExceptionFilter Class 
        /// </summary>
        /// <param name="id">This id is used to retrive the movie details by their movieids</param>
        /// <returns>Returns All the movie details of a movie based on given id as a HttpResponse message whether it is success or not</returns>
        [Route("api/MovieBrowserApi/GetMovieDetailsById/{id}")]
        [CustomExceptionFilter]
        public HttpResponseMessage GetMovieDetailsById(int id)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                var movie = bbl.GetMovieDetailsByMovieId(id);
                msg = Request.CreateResponse<Movie>(HttpStatusCode.OK, movie);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return msg;
        }
        /// <summary>
        /// To Get All the Movies From the Database
        /// Routing Defines the path to get this method
        /// when there is an exception it throws exception to CustomExceptionFilter Class
        /// </summary>
        /// <returns>Returns All the movies from the database as a httpresponsemessage code whether it is success or not</returns>
        [Route("api/MovieBrowserApi/GetAllMovies")]
        [CustomExceptionFilter]
        public  HttpResponseMessage GetAllMovies()
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                var moviesLst = bbl.GetAllMovies();
                msg = Request.CreateResponse<List<Movie>>(HttpStatusCode.OK, moviesLst);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return msg;
        }
        /// <summary>
        /// To Delete the Movie Details with the help of movieid given by the user
        /// Routing Defines the path to get this method
        /// when there is an exception it throws exception to CustomExceptionFilter Class 
        /// </summary>
        /// <param name="id">This id is used to delete the movie details by their movieids</param>
        /// <returns>Returns as a HttpResponse message whether it is successfully deleted or not</returns>
        [Route("api/MovieBrowserApi/DeleteMovieByMovieId/{id}")]
        [CustomExceptionFilter]
        public HttpResponseMessage DeleteMovieByMovieId(int id)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                bbl.DeleteMovieByMovieId(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return msg;
        }
        /// <summary>
        /// To Post the New Movie Details into the existing database
        /// when there is an exception it throws exception to CustomExceptionFilter Class 
        /// </summary>
        /// <param name="movie">Add/Post all the details of a movie</param>
        /// <returns>Returns as a HttpResponse message whether it is successfully Added or not</returns>
        [CustomExceptionFilter]
        public HttpResponseMessage Post([FromBody] Movie movie)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                bbl.AddMovieDetails(movie);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return msg;
        }
        /// <summary>
        /// To Update the Movie Details into the existing database
        /// when there is an exception it throws exception to CustomExceptionFilter Class 
        /// </summary>
        /// <param name="id">With the help of this movie id,we can edit the movie details</param>
        /// <param name="movie">The movie parameter used to get which movie has to be updated</param>
        /// <returns>Returns as a HttpResponse message whether it is successfully Updated or not</returns>
        [CustomExceptionFilter]
        public HttpResponseMessage Put([FromBody]Movie movie,int id)
        {
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK,"Movie Details SuccessFully Updated");
            try
            {
                bbl.UpdateMovieByMovieId(movie);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return msg;
        }
        /// <summary>
        /// To Get All the Actors and Genres present in the database
        /// Routing Defines the path to get this method
        /// when there is an exception it throws exception to CustomExceptionFilter Class 
        /// </summary>
        /// <returns>Returns as a HttpResponse message whether it is success or not</returns>
        [Route("api/MovieBrowserApi/GetAllActorsGenres")]
        [CustomExceptionFilter]
        public HttpResponseMessage GetAllActorsGenres()
        {
            HttpResponseMessage msg = Request.CreateErrorResponse(HttpStatusCode.OK, "Movie Details SuccessFully Updated");
            try
            {
                var actorsLst = bbl.GetAllActors();
                var genresLst = bbl.GetAllGenres();
                var movie = new Movie
                {
                    Actors = actorsLst,
                    Genres = genresLst
                };
                msg = Request.CreateResponse<Movie>(HttpStatusCode.OK, movie);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return msg;
        }
    }
}
