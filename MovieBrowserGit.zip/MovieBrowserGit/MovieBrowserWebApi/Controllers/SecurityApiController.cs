﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OMBEntitiesLib;//Imports All the Entities used in this Application from Entities Library Project
using OMBBusinessLayerLib;//Imports All the Functions used in this Application from BusinessLayer Library Project
using OMBExceptionLib;//Imports All the Exceptions used in this Application from database
namespace MovieBrowserWebAPI.Controllers
{
    public class SecurityApiController : ApiController
    {
        //Dependency Injection To the Business layer Interface
        private readonly IOMBBusinessLayer bbl;
        //constructor to invoke the variable coming from BusinessLayer Interface
        public SecurityApiController(IOMBBusinessLayer bbl)
        {
            this.bbl = bbl;
        }
        /// <summary>
        /// To Get UserName from the database With the given UserName by User
        ///Routing Defines the path to get this method
        ///when there is an exception it throws exception to CustomExceptionFilter Class 
        /// </summary>
        /// <param name="name">It is Used to pass the username to retrive username with this parameter</param>
        /// <returns>Returns the username from database as a HttpResponse message whether it is success or not</returns>
        [Route("api/SecurityApi/GetUserNameByName/{name}")]
        [CustomExceptionFilter]
        public HttpResponseMessage GetUserNameByName(string name)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                var userName = bbl.GetUserNameByName(name);
                msg = Request.CreateResponse<RegistrationDetail>(HttpStatusCode.OK, userName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return msg;
        }
        /// <summary>
        /// To Get User Password from the database With the given UserName by User
        ///Routing Defines the path to get this method
        ///when there is an exception it throws exception to CustomExceptionFilter Class 
        /// </summary>
        /// <param name="name">It is Used to pass the username to retrive user password with this parameter</param>
        /// <returns>Returns the user password from database as a HttpResponse message whether it is success or not</returns>
        [Route("api/SecurityApi/GetUserPwdByName/{name}")]
        [CustomExceptionFilter]
        public HttpResponseMessage GetUserPwdByName(string name)
        {

            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                var userPwd = bbl.GetUserPwdByName(name);
                msg = Request.CreateResponse<RegistrationDetail>(HttpStatusCode.OK, userPwd);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return msg;
        }
        /// <summary>
        /// This Method Adds the user details into the database to register the credentials
        /// Routing Defines the path to get this method
        /// when there is an exception it throws exception to CustomExceptionFilter Class 
        /// </summary>
        /// <param name="regDetail">With this Parameter we can add the userdetails into database</param>
        /// <returns>Return as a HttpResponse whether the details are added successfully or not</returns>
        [CustomExceptionFilter]
        public HttpResponseMessage Post([FromBody]RegistrationDetail regDetail)
        {
            HttpResponseMessage msg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                bbl.AddUserDetails(regDetail);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return msg;
        }
    }
}
