﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OMBEntitiesLib;//Imports All the Entities from the Entities Library Project
namespace OMBBusinessLayerLib
{
    public interface IOMBBusinessLayer
    {
        //This Method is used to get the user details from database
        UserDetail GetUserDetails();

        //This Method returns the List of Movies as per the movie name given by the user
        List<Movie> GetMoviesByName(string movieName);

        //This Method is used to get the movie details of a movie with the help of movie id given by the user
        Movie GetMovieDetailsByMovieId(int movieId);

        //This Method returns all the movies present in the database
        List<Movie> GetAllMovies();

        //This Method deletes the movie with help of movieid given by the user
        void DeleteMovieByMovieId(int movieId);

        //This Method adds the new Movie details to existing database
        void AddMovieDetails(Movie movie);

        //This Method is used to retrieve all the actors present in the database
        List<Actor> GetAllActors();

        //This Method is used to retrieve all the genres present in the database
        List<Genre> GetAllGenres();

        //This Method is used to update the movie details with the help of movieid
        void UpdateMovieByMovieId(Movie movie);

        //This Method is used to retrive the username from the database with the help of username given by the user
        RegistrationDetail GetUserNameByName(string name);

        //This Method is used to retrive the user password from the database with the help of username given by the user
        RegistrationDetail GetUserPwdByName(string name);

        //This Method is used to add the userdetails into existing database
        void AddUserDetails(RegistrationDetail regDetail);

    }
}
