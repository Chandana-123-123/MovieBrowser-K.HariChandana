﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OMBEntitiesLib;//Imports All the Entities used in this Application from Entities Library Project
using OMBBusinessLayerLib;//Imports All the Functions used in this Application from BusinessLayer Library Project
using OMBDataAccessLayerLib;//Imports All the Functions used in this Application from DataAccessLayer Library Project
using OMBExceptionLib;//Imports All the Exceptions used in this Application from database
namespace OMBBusinessLayerLib
{
    public class OMBBusinessLayer : IOMBBusinessLayer
    {
        //Dependency Injection To the DataAccesslayer Interface
        private readonly IOMBDataAccessLayer dal;

        //constructor to invoke the variable coming from DataAccessLayer Interface
        public OMBBusinessLayer(IOMBDataAccessLayer dal)
        {
            this.dal = dal;
        }


        /// <summary>
        /// To Add the New Movie Details into the existing database
        /// </summary>
        /// <param name="movie">Add/Post all the details of a movie</param>
        public void AddMovieDetails(Movie movie)
        {
           dal.AddMovieDetails(movie);
        }

        /// <summary>
        /// To Add the New user Details into the existing database
        /// </summary>
        /// <param name="regDetail">Add/Post all the details of a user</param>
        public void AddUserDetails(RegistrationDetail regDetail)
        {
            dal.AddUserDetails(regDetail);
        }


        /// <summary>
        /// To Get UserName from the database With the given UserName by User
        /// </summary>
        /// <param name="name">It is Used to pass the username to retrive username with this parameter</param>
        /// <returns>Returns the username from database</returns>
        public RegistrationDetail GetUserNameByName(string name)
        {
            var userName=dal.GetUserNameByName(name);
            return userName;
        }

        /// <summary>
        /// To Get UserPassword from the database With the given UserName by User
        /// </summary>
        /// <param name="name">It is Used to pass the username to retrive username with this parameter</param>
        /// <returns>Returns the username from database</returns>
        public RegistrationDetail GetUserPwdByName(string name)
        { 
            var userPwd = dal.GetUserPwdByName(name);
            return userPwd;
        }

        /// <summary>
        /// To Delete the Movie Details with the help of movieid given by the user
        /// </summary>
        /// <param name="id">This id is used to delete the movie details by their movieids</param>
        public void DeleteMovieByMovieId(int movieId)
        {
            dal.DeleteMovieByMovieId(movieId);
        }

        /// <summary>
        /// To Get All the Actors From the Database
        /// </summary>
        /// <returns>Returns All the Actors from the database</returns>
        public List<Actor> GetAllActors()
        {
            var actorsLst = dal.GetAllActors();
            return actorsLst;
        }


        /// <summary>
        /// To Get All the Genres From the Database
        /// </summary>
        /// <returns>Returns All the Genres from the database</returns>
        public List<Genre> GetAllGenres()
        {
            var genresLst = dal.GetAllGenres();
            return genresLst;
        }


        /// <summary>
        /// To Get All the Movies From the Database
        /// </summary>
        /// <returns>Returns All the movies from the database</returns>
        public List<Movie> GetAllMovies()
        {
            List<Movie> movieLst = dal.GetAllMovies();
            return movieLst;
        }


        /// <summary>
        /// To Update the Movie Details into the existing database
        /// </summary>
        /// <param name="movie">The movie parameter used to get which movie has to be updated</param>
        public void UpdateMovieByMovieId(Movie movie)
        {
            dal.UpdateMovieByMovieId(movie);
        }


        /// <summary>
        /// To Get All the Movie Details with the help of movieid given by the user
        /// </summary>
        /// <param name="id">This id is used to retrive the movie details by their movieids</param>
        /// <returns>Returns All the movie details of a movie based on given id</returns>
        public Movie GetMovieDetailsByMovieId(int movieId)
        {
            Movie movie = dal.GetMovieDetailsByMovieId(movieId);
            return movie;
        }


        /// <summary>
        /// To Get All the Movie Names from the database With the given movieName by User 
        /// </summary>
        /// <param name="movieName">It is Used to pass the moviename to retrive all the movies with this parameter</param>
        /// <returns>Returns All the users from database</returns>
        public List<Movie> GetMoviesByName(string movieName)
        {
            List<Movie> moviesLst = dal.GetMoviesByName(movieName);
            return moviesLst;
        }


        /// <summary>
        /// To Get All the User Details from the database
        /// </summary>
        /// <returns>Returns All the users from database</returns>
        public UserDetail GetUserDetails()
        {
            var user = dal.GetUserDetails();
            return user;
        }
    }
}
