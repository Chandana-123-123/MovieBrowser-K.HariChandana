﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;//Imports Packages for ADO.Net classes connection,command
using OMBEntitiesLib;
using OMBExceptionLib;
namespace OMBDataAccessLayerLib
{
    public class OMBDataAccessLayer : IOMBDataAccessLayer
    {
        SqlConnection con;
        SqlCommand cmd;
       
        /// <summary>
        /// Invoke constructor for the establishing of SqlDataConnection
        /// </summary>
        public OMBDataAccessLayer()
        {
            //configure connection object
             con = new SqlConnection();
            //Database connection string
            con.ConnectionString = @"Data Source=(localdb)\ProjectsV13;Initial Catalog=HCLDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultipleActiveResultSets=true;MultiSubnetFailover=False";
        }

        /// <summary>
        /// This Method is used to Add ActorId and MovieId in the database--
        /// --whenever new movie is getting added into the database
        /// </summary>
        /// <param name="movie">The Movie model is getting passed into this method</param>
        /// <param name="movieId">We can add actors with respect to this movie id</param>
        public void AddActorIdMovieId(Movie movie, int movieId)
        {
            try
            {
                //open the connection
                con.Open();
                foreach(var actor in movie.Actors)
                {
                    //configure commmand for INSERT statement
                    cmd = new SqlCommand();
                    cmd.CommandText = "insert into tbl_movieactor values(@mi,@ai)";
                    //supply values to the paramters of the command
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@mi", movie.MovieId);
                    cmd.Parameters.AddWithValue("@ai", actor.ActorId);
                    //specify the type of command
                    cmd.CommandType = System.Data.CommandType.Text;
                    //Attach the connection with the command
                    cmd.Connection = con;
                    //Execute the command
                    cmd.ExecuteNonQuery();
                }
            }
            catch (SqlException ex)
            {
                throw new OMBException("Cannot Add ActorId and MovieId" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Cannot Add ActorId and MovieId" + ex.Message);
            }
            finally
            {
                //close connection
                con.Close();
                AddGenreIdMovieId(movie, movie.MovieId);
            }

        }

        /// <summary>
        /// This Method is used to Add GenreId and MovieId in the database--
        /// --whenever new movie is getting added into the database
        /// </summary>
        /// <param name="movie">The Movie model is getting passed into this method</param>
        /// <param name="movieId">We can add genres with respect to this movie id</param>

        public void AddGenreIdMovieId(Movie movie, int movieId)
        {
            try
            {
                //open the connection
                con.Open();
                foreach (var genre in movie.Genres)
                {
                    //configure command for INSERT statement
                    cmd = new SqlCommand();
                    cmd.CommandText = "insert into tbl_moviegenre values(@mi,@gi)";
                    //supply values to the parameters of the command
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@mi", movie.MovieId);
                    cmd.Parameters.AddWithValue("@gi", genre.GenreId);
                    //specify the type of command
                    cmd.CommandType = System.Data.CommandType.Text;
                    //open the connection
                    cmd.Connection = con;
                    //Execute the command
                    cmd.ExecuteNonQuery();

                }

            }
            catch (SqlException ex)
            {
                throw new OMBException("Cannot Add GenreId and MovieId" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Cannot Add GenreId and MovieId" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }

        }
        /// <summary>
        /// This Method is used to Add New Movies in the database
        /// </summary>
        /// <param name="movie">The Movie model is getting passed into this method</param>
        public void AddMovieDetails(Movie movie)
        {
            try
            {
                //configure command for INSERT statement
                cmd = new SqlCommand();
                cmd.CommandText = "insert into tbl_movie values(@mn,@dir,@plot,@year,@box,@rel,@pic)";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@mn", movie.MovieName);
                cmd.Parameters.AddWithValue("@dir", movie.Director);
                cmd.Parameters.AddWithValue("@plot", movie.Plot);
                cmd.Parameters.AddWithValue("@year", movie.Year);
                cmd.Parameters.AddWithValue("@box", movie.BoxOffice);
                cmd.Parameters.AddWithValue("@rel", movie.ReleasedDate);
                cmd.Parameters.AddWithValue("@pic", movie.Pic);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute command
                cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw new OMBException("Cannot Add Movie Details" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Cannot Add Movie Details" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
                AddActorIdMovieId(movie, movie.MovieId);
            }
            
        }

        /// <summary>
        /// This Method is used to Delete the Movie in the database with movieid
        /// </summary>
        /// <param name="movieId">The Movie ID is getting passed into this method</param>
        public void DeleteMovieByMovieId(int movieId)
        {
            try
            {
                //configure command for DELETE statement
                cmd = new SqlCommand();
                cmd.CommandText = "delete from tbl_movie where movieid=@id";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", movieId);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute the command
                int recordsAffected = cmd.ExecuteNonQuery();
                if (recordsAffected == 0)
                {
                    throw new OMBException("Movie Details Could not be deleted");
                }
            }
            catch (SqlException ex)
            {
                throw new OMBException("Movie Details Could not be deleted" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Movie Details Could not be deleted" + ex.Message);
            }

        }
        /// <summary>
        /// This Method is used to retrive the Actors based on MovieId from the database
        /// </summary>
        /// <param name="movieId">With this parameter,we can get the list of Actors</param>
        /// <returns>Returns the List of Actors By MovieId</returns>
        public List<Actor> GetActorsByMovieID(int movieId)
        {
            List<Actor> actorsLst = new List<Actor>();
            try
            {
                //configure command for SELECT statement
                cmd = new SqlCommand();
                cmd.CommandText = "select a.actorname from tbl_actor as a,tbl_movieactor as ma,tbl_movie as m where m.movieid=ma.movieid and a.actorid=ma.actorid and m.movieid=@mid";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@mid", movieId);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Actor actor = new Actor
                    {
                        ActorName = sdr[0].ToString()
                    };
                    actorsLst.Add(actor);
                }
                //close the data reader
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException("Could Not Able To Get All the Actors By MovieId" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Could Not Able To Get All the Actors By MovieId" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }
            return actorsLst;
        }

        /// <summary>
        /// This Method is used to retrive All the Actors from the database
        /// </summary>
        /// <returns>Returns the List of Actors</returns>
        public List<Actor> GetAllActors()
        {
            List<Actor> actorsLst = new List<Actor>();
            try
            {
                //configure command for SELECT statement
                cmd = new SqlCommand();
                cmd.CommandText = "select * from tbl_actor";
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Actor actor = new Actor
                    {
                        ActorId = (int)sdr[0],
                        ActorName = sdr[1].ToString()

                    };
                    actorsLst.Add(actor);
                }
                //close the data reader
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException("Could Not Able To Get All the Actors" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Could Not Able To Get All the Actors" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }
            return actorsLst;
        }

        /// <summary>
        /// This Method is used to retrive All the Genres from the database
        /// </summary>
        /// <returns>Returns the List of Genres</returns>
        public List<Genre> GetAllGenres()
        {
            List<Genre> genresLst = new List<Genre>();
            try
            {
                //configure command for SELECT statement
                cmd = new SqlCommand();
                cmd.CommandText = "select * from tbl_genre";
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //Open the connection
                con.Open();
                //Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Genre genre = new Genre
                    {
                        GenreId = (int)sdr[0],
                        GenreName = sdr[1].ToString()

                    };
                    genresLst.Add(genre);
                }
                //close the data reader
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException("Could Not Able To Get All the Genres" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Could Not Able To Get All the Genres" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }
            return genresLst;
        }
        /// <summary>
        /// This Method is used to retrive All the Movies from the database
        /// </summary>
        /// <returns>Returns the List of Movies</returns>
        public List<Movie> GetAllMovies()
        {
            List<Movie> moviesLst = new List<Movie>();
            try
            {
                //configure command for SELECT statement
                cmd = new SqlCommand();
                cmd.CommandText = "select * from tbl_movie";
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //Open the connection
                con.Open();
                //Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Movie movie = new Movie
                    {
                        MovieId = (int)sdr[0],
                        MovieName = sdr[1].ToString(),
                        Director = sdr[2].ToString(),
                        Plot = sdr[3].ToString(),
                        Year = (int)sdr[4],
                        BoxOffice = sdr[5].ToString(),
                        ReleasedDate = (DateTime)sdr[6],
                        Pic = sdr[7].ToString(),
                    };
                    moviesLst.Add(movie);
                }
                //close the data reader
                sdr.Close();
            }
            
            catch (SqlException ex)
            {
                throw new OMBException("Could Not Able To Get All the Actors" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Could Not Able To Get All the Actors" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }
            return moviesLst;
        }
        /// <summary>
        /// This Method is used to retrive the Genres based on MovieId from the database
        /// </summary>
        /// <param name="movieId">With this parameter,we can get the list of Genres</param>
        /// <returns>Returns the List of Genres By MovieId</returns>
        public List<Genre> GetGenresByMovieID(int movieId)
        {
            List<Genre> genresLst = new List<Genre>();
            try
            {
                //configure command for SELECT statement
                cmd = new SqlCommand();
                cmd.CommandText = "select g.genrename from tbl_genre as g,tbl_moviegenre as mg,tbl_movie as m where m.movieid=mg.movieid and g.genreid=mg.genreid and m.movieid=@mid";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@mid", movieId);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Genre genre = new Genre
                    {
                        GenreName = sdr[0].ToString()
                    };
                    genresLst.Add(genre);
                }
                //close the data reader
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException("Could Not Able To Get All the Actors" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Could Not Able To Get All the Actors" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }
            return genresLst;
        }
        /// <summary>
        /// This method is used to retrive the details of a movie from the database
        /// </summary>
        /// <param name="movieId">With the help of this parameter,we can get the details of a particular movie</param>
        /// <returns>Returns the movie details by movie id</returns>
        public Movie GetMovieDetailsByMovieId(int movieId)
        {
            Movie movie = new Movie(); ;
            movie.Genres = GetGenresByMovieID(movieId);
            movie.Actors = GetActorsByMovieID(movieId);
            try
            {
                //configure command for SELECT statement
                cmd = new SqlCommand();
                cmd.CommandText = "select movieid,moviename,director,plot,year,boxoffice,releaseddate,picture from tbl_movie where movieid=@id";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", movieId);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the Movie Model
                if (sdr.Read())
                { 
                    movie.MovieId = (int)sdr[0];
                    movie.MovieName = sdr[1].ToString();
                    movie.Director = sdr[2].ToString();
                    movie.Plot = sdr[3].ToString();
                    movie.Year = (int)sdr[4];
                    movie.BoxOffice = sdr[5].ToString();
                    movie.ReleasedDate = (DateTime)sdr[6];
                    movie.Pic = sdr[7].ToString();
                }
                else
                {
                    throw new OMBException("Movie Details Does Not exists");
                }  
            }
            catch (SqlException ex)
            {
                throw new OMBException("Movie Details Does Not exists"+ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Movie Details Does Not exists"+ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }
            return movie;
        }

        /// <summary>
        /// This Method returns movies with the help of moviename from the database
        /// </summary>
        /// <param name="movieName">With this parameter,we can get all the movies</param>
        /// <returns>Returns the list of movies with the help of moviename</returns>
        public List<Movie> GetMoviesByName(string movieName)
        {
            List<Movie> moviesLst = new List<Movie>();
            try
            {
                Movie movies = null;
                //configure command for SELECT statement
                cmd = new SqlCommand();
                cmd.CommandText = "select * from tbl_movie where moviename like @mname";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@mname", "%" + movieName + "%");
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the Movie Model
                while (sdr.Read())
                {
                    movies = new Movie
                    {
                        MovieId = (int)sdr[0],
                        MovieName = sdr[1].ToString(),
                        Director = sdr[2].ToString(),
                        Plot = sdr[3].ToString(),
                        Year = (int)sdr[4],
                        BoxOffice = sdr[5].ToString(),
                        ReleasedDate = (DateTime)sdr[6],
                        Pic = sdr[7].ToString(),
                    };
                    moviesLst.Add(movies);
                }
                //close the connection
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException("Cannot Get MovieNames By MovieName" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Cannot Get MovieNames By MovieName" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }
            return moviesLst;
        }
        /// <summary>
        /// This method is used to retrive all the userdetails from the database
        /// </summary>
        /// <returns>Returns the user detail </returns>
        public UserDetail GetUserDetails()
        {
            UserDetail user = null;
            try
            {
                //configure command for SELECT statement
                cmd = new SqlCommand();
                cmd.CommandText = "select * from userdetail";
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //Open the connection
                con.Open();
                //Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the Movie Model
                if (sdr.Read())
                {
                    user = new UserDetail
                    {
                        Id = (int)sdr[0],
                        UserName = sdr[1].ToString(),
                        Picture = sdr[2].ToString(),
                    };
                }
                //close the reader
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException("Cannot Get UserDetails" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Cannot Get UserDetails" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }
            return user;
        }
        /// <summary>
        /// This method is used to update the details of movie which is exists in the database
        /// </summary>
        /// <param name="movie">With this parameter,the existing movie will get updated</param>
        public void UpdateMovieByMovieId(Movie movie)
        {
            try
            {
                //configure command for UPDATE statement
                cmd = new SqlCommand();
                cmd.CommandText = "update tbl_movie set moviename=@mn,picture=@pic,director=@dir,plot=@plot,year=@yr,boxoffice=@box,releaseddate=@rel where movieid=@movieId";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@movieId", movie.MovieId);
                cmd.Parameters.AddWithValue("@mn", movie.MovieName);
                cmd.Parameters.AddWithValue("@dir", movie.Director);
                cmd.Parameters.AddWithValue("@plot", movie.Plot);
                cmd.Parameters.AddWithValue("@yr", movie.Year);
                cmd.Parameters.AddWithValue("@box", movie.BoxOffice);
                cmd.Parameters.AddWithValue("@rel", movie.ReleasedDate);
                cmd.Parameters.AddWithValue("@pic", movie.Pic);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute Command
                int rowsaffected = cmd.ExecuteNonQuery();
                //close the connection
                con.Close();
                DeleteMovieGenresByMovieId(movie);
                if (rowsaffected == 0)
                {
                    throw new OMBException("Could not Update");
                }
            }
            catch (SqlException ex)
            {
                throw new OMBException("Cannot Update Movie Details" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Cannot Update Movie Details" + ex.Message);
            }

        }
        /// <summary>
        /// This Method is used to delete the genres of a movie based on the given movieid
        /// </summary>
        /// <param name="movie">With this parameter,the genres will get deleted from database</param>
        public void DeleteMovieGenresByMovieId(Movie movie)
        {
            try
            {
                //configure command for DELETE statement
                cmd = new SqlCommand();
                cmd.CommandText = "delete from tbl_moviegenre where movieid=@mid";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@mid", movie.MovieId);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute Command
                int rowsaffected = cmd.ExecuteNonQuery();
                //close the connection
                con.Close();
                DeleteMovieActorsByMovieId(movie);
                if (rowsaffected == 0)
                {
                    throw new OMBException("Could Not Delete Movie Genres");
                }
            }
            catch (SqlException ex)
            {
                throw new OMBException("Cannot Delete Movie Genres" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Cannot Delete Movie Genres" + ex.Message);
            }

        }
        /// <summary>
        /// This Method is used to delete the actors of a movie based on the given movieid
        /// </summary>
        /// <param name="movie">With this parameter,the actors will get deleted from database</param>
        public void DeleteMovieActorsByMovieId(Movie movie)
        {
            try
            {
                //configure command for DELETE statement
                cmd = new SqlCommand();
                cmd.CommandText = "delete from tbl_movieactor where movieid=@mid";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@mid", movie.MovieId);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute the command
                int rowsaffected = cmd.ExecuteNonQuery();
                cmd.ExecuteNonQuery();
                //close the connection
                con.Close();
                AddActorIdMovieId(movie, movie.MovieId);
                if (rowsaffected == 0)
                {
                    throw new Exception("Could Not Delete Movie Actors");
                }
            }
            catch (SqlException ex)
            {
                throw new OMBException("Cannot Delete Movie Actors" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Cannot Delete Movie Actors" + ex.Message);
            }
        }
        /// <summary>
        /// This Method is used to Add User Details in the database
        /// </summary>
        /// <param name="reg">The RegistrationDetail model is getting passed into this method</param>
        public void AddUserDetails(RegistrationDetail reg)
        {
            try
            {
                //configure command for INSERT statement
                cmd = new SqlCommand();
                cmd.CommandText = "insert into logindetails values(@un,@pwd,@cpwd)";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@un", reg.UserName);
                cmd.Parameters.AddWithValue("@pwd", reg.Password);
                cmd.Parameters.AddWithValue("@cpwd", reg.ConfirmPassword);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute the command
                cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw new OMBException("Cannot Add User Details" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("Cannot Add User Details" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }
        }
        /// <summary>
        /// This Method is used to get username by the given name from the database
        /// </summary>
        /// <param name="name">with this parameter we can get the username</param>
        /// <returns>Returns the UserName from  the database</returns>
        public RegistrationDetail GetUserNameByName(string name)
        {
            RegistrationDetail reg = new RegistrationDetail();
            try
            {
                //configure command for SELECT statement
                cmd = new SqlCommand();
                cmd.CommandText = "select username from logindetails where username=@un";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@un", name);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the Movie Model
                if (sdr.Read())
                {
                    reg.UserName = sdr[0].ToString();
                    //close the reader
                    sdr.Close();
                }
                else
                {
                    throw new OMBException("UserName Does Not Exists..!!!");
                }
            }
            catch (SqlException ex)
            {
                throw new OMBException("UserName Does Not Exists" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }
            return reg;
        }

        /// <summary>
        /// This Method is used to get userpassword by the given name from the database
        /// </summary>
        /// <param name="name">with this parameter we can get the user password</param>
        /// <returns>Returns the User Password from  the database</returns>
        public RegistrationDetail GetUserPwdByName(string name)
        {
            RegistrationDetail reg1 = new RegistrationDetail();
            try
            {
                //configure command for SELECT statement
                cmd = new SqlCommand();
                cmd.CommandText = "select password from logindetails where username=@un";
                //supply values to the parameters of the command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@un", name);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach the connection with command
                cmd.Connection = con;
                //Open the connection
                con.Open();
                //Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the Movie Model
                if (sdr.Read())
                {
                    reg1.Password = sdr[0].ToString();
                    //close the reader
                    sdr.Close();
                }
                else
                {
                    throw new OMBException("UserName Code Does Not Exists..!!!");
                }
            }
            catch (SqlException ex)
            {
                throw new OMBException("UserName Does Not Exists....!!!!" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException("UserName Does Not Exists.....!!!" + ex.Message);
            }
            finally
            {
                //close the connection
                con.Close();
            }
            return reg1;
        }
    }
}
