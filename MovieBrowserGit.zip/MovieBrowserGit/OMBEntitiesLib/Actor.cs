﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OMBEntitiesLib
{
    public class Actor
    {
        /// <summary>
        ///  Id of an Actor
        /// </summary>

        public int ActorId { get; set; }

        /// <summary>
        ///  Name of an Actor
        /// </summary>

        public string ActorName { get; set; }
    }
}
