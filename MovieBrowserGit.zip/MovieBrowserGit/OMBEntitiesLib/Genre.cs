﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OMBEntitiesLib
{
    public class Genre
    {
        /// <summary>
        /// Id of Genre
        /// </summary>
        public int GenreId { get; set; }

        /// <summary>
        /// Name of the Genre
        /// </summary>
        public string GenreName { get; set; }
    }
}
