﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OMBEntitiesLib
{
    public class Login
    {
        /// <summary>
        /// Existing UserName in the database
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        ///  Password for the UserName
        /// </summary>
        public string Password { get; set; }
    }
}
