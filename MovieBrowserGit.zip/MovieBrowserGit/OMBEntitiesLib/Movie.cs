﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OMBEntitiesLib
{
    public class Movie
    {
        /// <summary>
        /// The Identity of a Movie
        /// </summary>
        public int MovieId { get; set; }

        /// <summary>
        /// The Name of Movie
        /// </summary>
        public string MovieName { get; set; }

        /// <summary>
        /// The Director of Movie
        /// </summary>
        public string Director { get; set; }

        /// <summary>
        /// The Year of Movie Released
        /// </summary>
        public int Year { get; set; }

        /// <summary>
        /// Plot for the Movie
        /// </summary>
        public string Plot { get; set; }

        /// <summary>
        /// Box Office Collection for movie
        /// </summary>
        public string BoxOffice { get; set; }

        /// <summary>
        /// Released Date and Time of a movie
        /// </summary>
        public DateTime ReleasedDate { get; set; }

        /// <summary>
        /// List of Genres based on the Genre Class which is having Genre Id and Genre Name
        /// </summary>
        public List<Genre> Genres { get; set; }

        /// <summary>
        /// List of Actors based on the Actor Class which is having Actor Id and Actor Name
        /// </summary>
        public List<Actor> Actors { get; set; }

        /// <summary>
        /// The Picture for the movie
        /// </summary>
        public string Pic { get; set; }
    }
}
