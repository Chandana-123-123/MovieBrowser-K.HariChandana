﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OMBEntitiesLib
{
    public class RegistrationDetail
    {
        /// <summary>
        /// UserName of the User to get Registered in the database
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Password For the User
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// Confirm Password For the User
        /// </summary>
        public string ConfirmPassword { get; set; }
    }
}
