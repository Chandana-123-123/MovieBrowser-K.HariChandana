﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Filters;

namespace OMBExceptionLib
{
    public class CustomExceptionFilter:ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            //base.OnException(actionExecutedContext);
            string msg = actionExecutedContext.Exception.Message;
            HttpResponseMessage res = new HttpResponseMessage
            {
                Content = new StringContent(msg),
                StatusCode = System.Net.HttpStatusCode.BadRequest,
                ReasonPhrase = "Internal Server Error"
            };
            actionExecutedContext.Response = res;   
            
        }
    }
}
