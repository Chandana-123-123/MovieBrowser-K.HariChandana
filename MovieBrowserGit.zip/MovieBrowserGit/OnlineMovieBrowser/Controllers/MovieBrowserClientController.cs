﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using OnlineMovieBrowser.Models;
using OMBExceptionLib;

namespace OnlineMovieBrowser.Controllers
{
    public class MovieBrowserClientController : Controller
    {
        // GET: OnlineMovieBrowser
        /// <summary>
        /// This Method Should Return The  Browse View When it is Called
        /// </summary>
        /// <returns>The First Page Of MovieBrowser Application</returns>
        public ActionResult Browse()
        {
            return View();
        }

        /// <summary>
        /// When the browse view is called,the parameter we send from the get view should--
        /// --post into this view and displays the movie names along with details
        /// </summary>
        /// <param name="movieName">With this parameter it retrives all the movie names</param>
        /// <returns>Return the View which displays list of movies with the given name</returns>
        [HttpPost]
        public ActionResult Browse(string movieName)
        {
            //If Server-Side Validation is success/valid 
            if(ModelState.IsValid)
            {
                //This uri defines the connection to Api controller on which it should get data
                Uri uri = new Uri("http://localhost:50437/api/");
                using (var client = new HttpClient())
                {
                    client.BaseAddress = uri;
                    //Get the movies by passing parameter(moviename) from WebApi 
                    var result = client.GetStringAsync("MovieBrowserApi/GetMoviesByName/" + movieName).Result;
                    //converts the data into Json for readabilty and store it to a variable
                    var moviesLst = JsonConvert.DeserializeObject<List<Movie>>(result);

                    //If there are movies based on the given name returns the view
                    if (moviesLst.Count != 0)
                    {
                        var msg = movieName;
                        ViewData.Add("msg", msg);
                        return View("GetMoviesByName", moviesLst);
                    }

                    //  //If there are no movies based on the given name returns the View that movies are not found
                    else
                    {
                        return View("MovieNotFound");
                    }
                }
            }
            //If Server-Side Validations is not valid returns the same view
           else
            {
                return View(movieName);
            }
        }
        /// <summary>
        /// This Method Displays the Movie Details based on the movie id
        /// </summary>
        /// <param name="id">With this parameter,it displays all the movie details</param>
        /// <returns>Returns all the details of a selected movie</returns>
        public ActionResult DisplayMovieDetailsById(int id)
        {
            //This uri defines the connection to Api controller on which it should get data
            Uri uri = new Uri("http://localhost:50437/api/");
           using (var client = new HttpClient())
           {
             client.BaseAddress = uri;
             //Get the movie details by passing parameter(movieid) from WebApi 
             var result = client.GetStringAsync("MovieBrowserApi/GetMovieDetailsById/" + id).Result;
             //converts the data into Json for readabilty and store it to a variable
             var movie = JsonConvert.DeserializeObject<Movie>(result);
             //Returns the View with data
             return View(movie);
           }
        }

        /// <summary>
        /// This method is used to display all the movies present in the database
        /// </summary>
        /// <returns>Returns the view contains all the list of movies</returns>
        public ActionResult DisplayAllMovies()
        {
            //This uri defines the connection to Api controller on which it should get data
            Uri uri = new Uri("http://localhost:50437/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                //Get all movies present in the database from WebApi 
                var result = client.GetStringAsync("MovieBrowserApi/GetAllMovies").Result;
                //converts the data into Json for readabilty and store it to a variable
                var moviesLst = JsonConvert.DeserializeObject<List<Movie>>(result);
                
                //performing sorted operation based on movieid,moviename and year
                string sortOrder = Request.QueryString.Get("sortOrder");
                switch (sortOrder)
                {
                    case "MovieId":
                        moviesLst = moviesLst.OrderBy(o => o.MovieId).ToList();
                        break;
                    case "MovieName":
                        moviesLst = moviesLst.OrderBy(o => o.MovieName).ToList();
                        break;
                    case "Year":
                        moviesLst = moviesLst.OrderBy(o => o.Year).ToList();
                        break;
                }
                //Returns the view with data
                return View(moviesLst); 
            }
        }

        /// <summary>
        /// This method deletes the movie based on the movieid given by the user
        /// </summary>
        /// <param name="id">With this parameter,the movie gets deleted</param>
        /// <returns>Returns The Message whether the movie is deleted successfully or not </returns>
        /// Authorize Filter is used for security purpose so that only Admin can Access/modifies the data
        [Authorize]
        public ActionResult DeleteMovieByMovieId(int id)
        {
            //This uri defines the connection to Api controller on which it should get data
            Uri uri = new Uri("http://localhost:50437/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                //Delete movie based on the movie id present in the database from WebApi
                var result = client.DeleteAsync("MovieBrowserApi/DeleteMovieByMovieId/" + id).Result;
                if (TempData["msg"] != null)
                {
                    TempData.Remove("msg");
                }
                if (result.IsSuccessStatusCode == true)
                {
                    TempData.Add("msg1", "Movie details deleted successfully");
                }
                else
                {
                    TempData.Add("msg2", "Movie details could not be deleted");
                }
                //Returns the same view to display the message 
                return RedirectToAction("DisplayAllMovies");
            }
        }

        /// <summary>
        /// This method is used to get the view that takes the details of new movies
        /// </summary>
        /// <returns>Returns the view to add new Movie details</returns>
        /// Authorize Filter is used for security purpose so that only Admin can Access/modifies the data
        [Authorize]
        public ActionResult AddMovieDetails()
        {
            //This uri defines the connection to Api controller on which it should get data
            Uri uri = new Uri("http://localhost:50437/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                //This Method is used to get all the actors and genres of movie in that view and store it in a variable
                var result = client.GetStringAsync("MovieBrowserApi/GetAllActorsGenres").Result;
                //converts the data into Json for readabilty and store it to a variable
                var movie = JsonConvert.DeserializeObject<Movie>(result);
                //Retrives the actors and genres from api and store into the fields in the MovieVM model
                var moviesVM = new MovieVM
                {
                    Actors = new MultiSelectList(movie.Actors, "ActorId", "ActorName"),
                    Genres = new MultiSelectList(movie.Genres, "GenreId", "GenreName")
                };
                //Returns the View with that details 
                return View(moviesVM);
            }
        }

        /// <summary>
        /// This method is used to post the the details of new movies to view
        /// </summary>
        /// <param name="movieVM">Post this model to the view</param>
        /// <returns>Returns the view when new Movie details are added and displays message</returns>
        /// Authorize Filter is used for security purpose so that only Admin can Access/modifies the data
        [HttpPost]
        public ActionResult AddMovieDetails(MovieVM movieVM)
        {
            //This uri defines the connection to Api controller on which it should get data
            Uri uri = new Uri("http://localhost:50437/api/");
                using (var client = new HttpClient())
                {
                    client.BaseAddress = uri;
                     //storing all the details in MovieVM model to Movie model
                    var movie = new Movie
                    {
                        MovieId = movieVM.MovieId,
                        MovieName = movieVM.MovieName,
                        Director = movieVM.Director,
                        Plot = movieVM.Plot,
                        Year = movieVM.Year,
                        Pic = movieVM.Pic,
                        Actors = movieVM.SelectedActors.Select(o => new Actor { ActorId = Convert.ToInt32(o) }).ToList(),
                        Genres = movieVM.SelectedGenres.Select(o => new Genre { GenreId = Convert.ToInt32(o) }).ToList(),
                        BoxOffice = movieVM.BoxOffice,
                        ReleasedDate = movieVM.ReleasedDate
                    };
                    //Post all the New Movie Details to Api
                    var result = client.PostAsJsonAsync("MovieBrowserApi", movie).Result;
                    if (result.IsSuccessStatusCode == true)
                    {
                        TempData.Add("msg1", "Movie details Added successfully");
                    }
                    else
                    {
                        TempData.Add("msg2", "Movie details could not be Added");
                    }
                    //Returns the Same View to display message success or not
                    return RedirectToAction("AddMovieDetails");
                }
        }
        /// <summary>
        /// This method is used to get the view that displays the details of existing movie
        /// </summary>
        /// <param name="id">With this parameter it displays the movie details</param>
        /// <returns>Returns the view to modify/update existing Movie details</returns>
        /// Authorize Filter is used for security purpose so that only Admin can Access/modifies the data

        [Authorize]
        [HttpGet]
        public ActionResult UpdateMovieDetails(int id)
        {
            //This uri defines the connection to Api controller on which it should get data
            Uri uri = new Uri("http://localhost:50437/api/");
                using (var client = new HttpClient())
                {
                    client.BaseAddress = uri;
                //This Method is used to get moviedetails by movieid in that view and store it in a variable
                var result = client.GetStringAsync("MovieBrowserApi/GetMovieDetailsById/" + id).Result;
                //This Method is used to get all the actors and genres of movie in that view and store it in a variable
                var result1 = client.GetStringAsync("MovieBrowserApi/GetAllActorsGenres").Result;
                //converts the data into Json for readabilty and store it to a variable
                var movie1 = JsonConvert.DeserializeObject<Movie>(result);
                //converts the data into Json for readabilty and store it to a variable
                var movie2 = JsonConvert.DeserializeObject<Movie>(result1);
                //Assiging to MovieVM model
                    var movieVM = new MovieVM
                    {
                    MovieId = movie1.MovieId,
                    MovieName = movie1.MovieName,
                    Pic = movie1.Pic,
                    Director = movie1.Director,
                    Plot = movie1.Plot,
                    Year = movie1.Year,
                    Actors = new MultiSelectList(movie2.Actors, "ActorId", "ActorName"),
                    Genres=new MultiSelectList(movie2.Genres,"GenreId","GenreName"),
                    BoxOffice=movie1.BoxOffice,
                    ReleasedDate=movie1.ReleasedDate
                    };
                //Returns the view with this data
                    return View(movieVM);
                }
        }

        /// <summary>
        /// This method is used to Update the the details of existing movie to view
        /// </summary>
        /// <param name="movieVM">Update this model to the view</param>
        /// <returns>Returns the view when Updated Movie details and displays message</returns>
        /// Authorize Filter is used for security purpose so that only Admin can Access/modifies the data
        [HttpPost]
        public ActionResult UpdateMovieDetails(MovieVM movieVM)
        {
            //This uri defines the connection to Api controller on which it should get data
            Uri uri = new Uri("http://localhost:50437/api/");
            using (var client = new HttpClient())
            {
                var movie = new Movie()
                {
                    MovieId = movieVM.MovieId,
                    MovieName = movieVM.MovieName,
                    Director = movieVM.Director,
                    Plot = movieVM.Plot,
                    Year = movieVM.Year,
                    Pic = movieVM.Pic,
                    Actors = movieVM.SelectedActors.Select(o => new Actor { ActorId = Convert.ToInt32(o) }).ToList(),
                    Genres = movieVM.SelectedGenres.Select(o => new Genre { GenreId = Convert.ToInt32(o) }).ToList(),
                    BoxOffice = movieVM.BoxOffice,
                    ReleasedDate = movieVM.ReleasedDate
                };
                client.BaseAddress = uri;
                //Post all the updations of Movie Details to Api
                var result = client.PutAsJsonAsync("MovieBrowserApi/" + movie.MovieId, movie).Result;
                if (result.IsSuccessStatusCode == true)
                {
                    ViewData.Add("msg1", "Movie details Added successfully");
                }
                else
                {
                    ViewData.Add("msg2", "Movie details could not be Added");
                }
                //Returns the same view tom display message whether it is success or not
                return RedirectToAction("DisplayAllMovies");
            }
        }
       /// <summary>
       /// This method is used to display the profile of Admin in the view
       /// </summary>
       /// <returns>Returns the View Which displays the Profile of the Admin of this Application</returns>
        public new ActionResult Profile()
        {
            return View();
        }

        /// <summary>
        /// This method is used to display the Contact Details of Admin in the view
        /// </summary>
        /// <returns>Returns the View Which displays the Contact Details of the Admin of this Application</returns>
        public ActionResult Contact()
        {
            var phnno = "+91 8121852314";
            var mail1 = "chandanah249@gmail.com";
            var mail2 = "kondahari.chandana@hcl.com";
            ViewData.Add("phnno", phnno);
            ViewData.Add("mail1", mail1);
            ViewData.Add("mail2", mail2);
            return View();
          
        }
    }
}