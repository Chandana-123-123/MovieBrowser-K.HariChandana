﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using OnlineMovieBrowser.Models;//Imports Model classes
using OMBExceptionLib;
using System.Web.Security;//Imports all the features of Security Authorization purpose

namespace OnlineMovieBrowser.Controllers
{
    public class SecurityController : Controller
    {
        // GET: Security
        /// <summary>
        /// This Method Invokes When there is an [Authorize] filter for any method
        /// Asks for login details to access the authorized page/view
        /// </summary>
        /// <returns>Returns View Which asks for Login Credentials to Access the Method</returns>
        [HttpGet]
        public ActionResult Login()
        {
            var returnUrl = Request.QueryString.Get("ReturnUrl");
            ViewData.Add("returnUrl", returnUrl);
            return View();
        }

        /// <summary>
        /// This Method Invokes When there is an [Authorize] filter for any method
        /// Post all the details into database and checks valid or not in the Get view
        /// </summary>
        /// <param name="login">With this parameter it gets stored into the Login Model</param>
        /// <returns>Returns View After successful login</returns>
        [HttpPost]
        public ActionResult Login(Login login)
        {
            using (var client = new HttpClient())
            {
                //This uri defines the connection to Api controller on which it should get data
                client.BaseAddress = new Uri("http://localhost:50437/api/SecurityApi/");
                //Get the UserName  based on the Username Given by the user from WebApi
                var result = client.GetStringAsync("GetUserNameByName/" + login.UserName).Result;
                //converts the data into Json for readabilty and store it to a variable
                RegistrationDetail name = JsonConvert.DeserializeObject<RegistrationDetail>(result);
                string uname = name.UserName;
                //Get the User Password based on the Username Given by the user from WebApi
                var result1 = client.GetStringAsync("GetUserPwdByName/" + login.UserName).Result;
                //converts the data into Json for readabilty and store it to a variable
                RegistrationDetail pwd = JsonConvert.DeserializeObject<RegistrationDetail>(result1);
                string upwd = pwd.Password;
                //checks whether login credentials are valid or not
                    if ((login.UserName.Equals(uname)) && (login.Password.Equals(upwd)))
                    {
                        FormsAuthentication.SetAuthCookie(login.UserName, false);
                        var returnUrl = Request.Form["returnUrl"];
                        return RedirectToLocal(returnUrl);
                    }
                    else
                    {
                        ViewData.Add("ErrMsg", "UserName and Password are Invalid,Please try again...!!!");
                    }
                    //Return Url is used to get the view when it is successfully login
                    var returnUrl2 = Request.QueryString.Get("ReturnUrl");
                    ViewData.Add("returnUrl", returnUrl2);
                    return View();
               
                
            }
        }
        /// <summary>
        /// Used for Returning the url
        /// </summary>
        /// <param name="returnUrl">With this parameter it redirects to local view</param>
        /// <returns>Returns the view when the url is valid</returns>
        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("AddMovieDetails", "MovieBrowserClient");
            }
        }
        /// <summary>
        /// This Method is used to display Registration Form for new user
        /// This Method Invokes When there is an [Authorize] filter for any method
        /// </summary>
        /// <returns>Returns the view with Registration Detail model</returns>
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }
        /// <summary>
        /// This Method Invokes When there is an [Authorize] filter for any method
        /// Post all the details into database and checks valid or not in the Get view
        /// </summary>
        /// <param name="regdetail">With this parameter,the details get posted into database</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Register(RegistrationDetail regdetail)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    //This uri defines the connection to Api controller on which it should get data
                    client.BaseAddress = new Uri("http://localhost:50437/api/");
                    //converts the data into Json for readabilty and store it to a variable
                    var result = client.PostAsJsonAsync("SecurityApi", regdetail).Result;
                    ViewData.Add("msg", "Your Registration Is Successful..!!!!");
                    //Returns the View with displaying success message
                    return View();
                }
                catch(Exception ex)
                {
                    //When exception Occurred returns the view with Failure Message
                    ViewData.Add("ErrMsg", "Cannot Insert Credentials into database,Please Register Again..!!!!" + ex.Message) ;
                    return View();
                }
               
            }
        }
        /// <summary>
        /// After Clicking Logout Button in the view it gets posted to here and gets the View 
        /// </summary>
        /// <returns>Returns The "Logout View" displaying as successfully logged out</returns>
        [HttpPost]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return View("Logout");
        }

    }
}
