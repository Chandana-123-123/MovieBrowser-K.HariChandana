﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineMovieBrowser.Models
{
    public class Genre
    {
        /// <summary>
        /// Id of Genre
        /// </summary>
        public int GenreId { get; set; }

        /// <summary>
        /// Name of the Genre
        /// </summary>
        public string GenreName { get; set; }
    }
}