﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;//Imports DataAnnotations from library
namespace OnlineMovieBrowser.Models
{
    public class Login
    {
        /// <summary>
        /// Existing UserName in the database
        /// With validations
        /// </summary>
        [Required(ErrorMessage ="User Name Should Not Be Empty")]
        public string UserName { get; set; }


        /// <summary>
        ///  Password for the UserName
        ///  With validations
        /// </summary>
        [Required(ErrorMessage = "Password Should Not Be Empty")]
        public string Password { get; set; }
    }
}