﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;//Imports DataAnnotations from library project
namespace OnlineMovieBrowser.Models
{
    public class MovieVM
    {
        /// <summary>
        /// The Identity of a Movie With Validations
        /// </summary>
        [Required]
        public int MovieId { get; set; }

        /// <summary>
        /// The Name of Movie With Validations
        /// </summary>
        [Required]
        public string MovieName { get; set; }

        /// <summary>
        /// The Director of Movie With Validations
        /// </summary>
        [Required]
        public string Director { get; set; }

        /// <summary>
        /// The Year of Movie Released With Validations
        /// </summary>
        [Required]
        public int Year { get; set; }

        /// <summary>
        /// Plot for the Movie With Validations
        /// </summary>
        [Required]
        public string Plot { get; set; }


        /// <summary>
        /// Box Office Collection for movie With Validations
        /// </summary>
        [Required]
        public string BoxOffice { get; set; }

        /// <summary>
        /// Released Date and Time of a movie With Validations
        /// </summary>
        [Required]
        public DateTime ReleasedDate { get; set; }

        /// <summary>
        /// Multi select list for Genres With Validations
        /// </summary>
        [Required]
        public MultiSelectList Genres { get; set; }

        /// <summary>
        /// List of strings to display selected Genres With Validations
        /// </summary>
        [Required]
        public List<string> SelectedGenres { get; set; }

        /// <summary>
        /// Multi select list for Genres With Validations
        /// </summary>
        [Required]
        public MultiSelectList Actors { get; set; }

        /// <summary>
        /// List of strings to display selected Genres With Validations
        /// </summary>
        [Required]
        public List<string> SelectedActors { get; set; }

        /// <summary>
        /// The Picture for the movie With Validations
        /// </summary>
        [Required]
        public string Pic { get; set; }
        
    }
}