﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;//Imports all Data Annotations from library project
namespace OnlineMovieBrowser.Models
{
    public class RegistrationDetail
    {

        /// <summary>
        /// UserName of the User to get Registered in the database
        /// With the Validation as required field and displaying Error Message
        /// Checking that UserName should contains only Alphabets
        /// </summary>
        [Required(ErrorMessage ="UserName Should Not Be Empty")]
        [RegularExpression("[aA-zZ]*", ErrorMessage = "Only alphabets A-Z are allowed")]
        public string UserName { get; set; }


        /// <summary>
        /// Password For the User
        /// With the Validation as required field and displaying Error Message
        /// Checking that Password should contains 5 to 10 digits
        /// </summary>
        [Required(ErrorMessage = "Password Should Not Be Empty")]
        [StringLength(10,MinimumLength =5, ErrorMessage = "Password must be 10 digits")]
        public string Password { get; set; }


        /// <summary>
        /// Confirm Password For the User
        /// With the Validation as required field and displaying Error Message
        /// Also Checking Whether Confirm Password should match with Password or not
        /// </summary>
        [Required(ErrorMessage = "Confirm Password Should Not Be Empty")]
        [Display(Name="Confirm Password")]
        [Compare(nameof(Password),ErrorMessage ="Password Does Not Match")]
        public string ConfirmPassword { get; set; }
    }
}