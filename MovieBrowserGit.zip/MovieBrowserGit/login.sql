﻿create table logindetails(username varchar(50) primary key,
password varchar(50),confirmpassword varchar(50))

insert into logindetails values
('chandu','chandu123','chandu123')

select * from logindetails